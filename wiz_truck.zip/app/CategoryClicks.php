<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CategoryClicks extends Model
{
    //
}
