<?php

namespace App\Http\Controllers;

use App\Ridderlogs;
use Illuminate\Http\Request;

class RidderlogsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Ridderlogs  $ridderlogs
     * @return \Illuminate\Http\Response
     */
    public function show(Ridderlogs $ridderlogs)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Ridderlogs  $ridderlogs
     * @return \Illuminate\Http\Response
     */
    public function edit(Ridderlogs $ridderlogs)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Ridderlogs  $ridderlogs
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Ridderlogs $ridderlogs)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Ridderlogs  $ridderlogs
     * @return \Illuminate\Http\Response
     */
    public function destroy(Ridderlogs $ridderlogs)
    {
        //
    }
}
