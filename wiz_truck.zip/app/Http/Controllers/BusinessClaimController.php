<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BusinessClaimController extends Controller
{
    //
}
