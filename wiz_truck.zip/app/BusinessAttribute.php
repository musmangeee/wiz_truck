<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BusinessAttribute extends Model
{
    //
}
