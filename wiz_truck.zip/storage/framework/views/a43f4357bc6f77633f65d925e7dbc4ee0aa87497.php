

<?php $__env->startSection('style'); ?>
    <style>
        .rating {
            font-size: 1rem;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('frontend.partials.default_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <!-- CARDS -->
    <div class="container mt-5">

        <?php if(Auth::user()->email_verified_at == null): ?>
            <div class="alert alert-light lift" role="alert">
                <div class="row">
                    <div class="col-auto">
                        <i class="fa fa-envelope text-secondary h1 mb-0"></i>
                    </div>
                    <div class="col-10">
                        Looks like you still have to confirm your account. Any reviews you write won’t be posted until you do.
                        Check your inbox and spam folders for a confirmation email, or click here to resend.
                    </div>
                </div>
            </div>
        <?php endif; ?>
            <?php if(Auth::user()->claim != ""): ?>
          <div class="alert alert-light lift" role="alert">
                <div class="row">
                    <div class="col-auto">
                        <i class="fa fa-store text-secondary h1 mb-0"></i>
                    </div>
                    <div class="col-10">
                        Thank you for claiming your business, we are checking your claim, will notify you soon.
                    </div>
                </div>
            </div>
                  <?php endif; ?>
        <?php if(Session::has('success')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-8">

                <!-- Value  -->


            </div>
            <div class="col-md-4">
                <h2 class="heading text-primary">Been to these businesses recently?</h2>
              
            </div>
        </div>
        <!-- / .row -->

    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wiz_truck\resources\views/backend/index.blade.php ENDPATH**/ ?>