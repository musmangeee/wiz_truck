

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-12 col-lg-10 col-xl-8">

            <!-- Header -->
            <div class="header mt-md-5">
                <div class="header-body">
                    <div class="row align-items-center">
                        <div class="col">

                            <!-- Pretitle -->
                            <h6 class="header-pretitle">
                                 Business
                            </h6>

                            <!-- Title -->
                            <h1 class="header-title">
                               Update Business
                            </h1>

                        </div>
                    </div> <!-- / .row -->
                </div>
            </div>
            <?php if(Session::has('success')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
            <?php endif; ?>
            <?php if(Session::has('error')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
            <?php endif; ?>

            <!-- Form -->
            <form role="form" action="" method="POST" >
                <input type="hidden" name="_method" value="PUT">
                <?php echo csrf_field(); ?>

                <!-- Project name -->
                <div class="form-group">

                    <!-- Label  -->
                    <label>
                        Business name
                    </label>

                    <!-- Input -->
                    <input type="text" name="name" value="<?php echo e($business->name); ?>" class="form-control">

                </div>

                <!-- Project description -->
                <div class="form-group">

                    <!-- Label -->
                    <label class="mb-1">
                        description
                    </label>
                    <!-- Textarea -->
                    <textarea name="description" class="form-control"><?php echo e($business->description); ?></textarea>

                    

                </div>

                <div class="form-group">

                    <!-- Label -->
                    <label class="mb-1">
                        Message
                    </label>
                    <!-- Textarea -->
                    <textarea name="message" class="form-control"><?php echo e($business->message); ?></textarea>

                </div>

                <!-- Project tags -->
                <div class="form-group">

                    <!-- Label -->
                    <label>
                        Category
                    </label>

                    <!-- Select -->
                    <select class="form-control" data-toggle="select" name="category_id">
                        <option value=""></option>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=""> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>

                <div class="row">
                    <div class="col-12 col-md-6">

                        <!-- Start date -->
                        <div class="form-group">

                            <!-- Label -->
                            <label>
                                Latitude
                            </label>

                            <!-- Input -->
                            <input type="text" name="latitude" class="form-control" value="<?php echo e($business->latitude); ?>">


                        </div>

                    </div>
                    <div class="col-12 col-md-6">

                        <!-- Start date -->
                        <div class="form-group">

                            <!-- Label -->
                            <label>
                                Longitude
                            </label>

                            <!-- Input -->
                            <input type="text" name="longitude" class="form-control" value="<?php echo e($business->longitude); ?>">


                        </div>

                    </div>
                </div> <!-- / .row -->
                <div class="row">
                    <div class="col-12 col-md-6">

                        <!-- Start date -->
                        <div class="form-group">

                            <!-- Label -->
                            <label>
                                URL
                            </label>

                            <!-- Input -->
                            <input type="url" name="url" class="form-control" value="<?php echo e($business->url); ?>">
                        </div>

                    </div>
                    <div class="col-12 col-md-6">

                        <!-- Start date -->
                        <div class="form-group">

                            <!-- Label -->
                            <label>
                                Hours
                            </label>

                            <!-- Input -->
                            <input type="text" name="hours" class="form-control" value="<?php echo e($business->hours); ?>">


                        </div>

                    </div>
                </div> <!-- / .row -->
                <div class="col-12 col-md-6">

                    <!-- Start date -->
                    <div class="form-group">

                        <!-- Label -->
                        <label>
                            Phone
                        </label>

                        <!-- Input -->
                        <input type="number" name="phone" class="form-control" value="<?php echo e($business->phone); ?>">


                    </div>

                </div>

                <div class="row">

                </div> <!-- / .row -->

                <!-- Divider -->
                <hr class="mt-5 mb-5">

                <!-- Buttons -->
                <input type="submit" name="submit" value="Update Project" class="btn btn-block btn-primary">

                
                <a href="<?php echo e(route('business.index')); ?>" class="btn btn-block btn-link text-muted">
                    Cancel this Business
                </a>

            </form>

        </div>
    </div> <!-- / .row -->
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Work\Wiz_truck\wiz_truck\resources\views/admin/business/detail.blade.php ENDPATH**/ ?>