

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('frontend.partials.default_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container mt-5">
        <div class="card-columns">
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <!-- Card -->

                    <div class="card review-card">
                        <?php if(count($review->images) == 1): ?>
                            <img src="<?php echo e(asset('storage/app/public/' . $review->images[0]->name)); ?>" alt="..." class="card-img-top">
                        <?php elseif(count($review->images) > 1): ?>
                            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">

                                <div class="carousel-inner">
                                    <?php $__currentLoopData = $review->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="carousel-item card-img-top <?php if(($key-1)==0): ?> active <?php endif; ?>"
                                             style="background-image: url('<?php echo e(asset('storage/app/public/' .$image->name)); ?>');">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button"
                                   data-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Previous</span>
                                </a>
                                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button"
                                   data-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </div>
                        <?php endif; ?>
                    <!-- Body -->
                        <div class="card-body">
                            <div class="mb-3">
                                <div class="row align-items-center">
                                    <div class="col-auto">

                                        <!-- Avatar -->
                                        <a href="#!" class="avatar">
                                            <img src="<?php echo e(asset('backend/assets/img/avatars/profiles/avatar-1.jpg')); ?>"
                                                 alt="..." class="avatar-img rounded-circle">
                                        </a>

                                    </div>
                                    <div class="col ml-n2">

                                        <!-- Title -->
                                        <h4 class="mb-1">
                                            <?php echo e(Auth::user()->name); ?>

                                        </h4>

                                        <!-- Time -->
                                        <p class="card-text small text-muted">
                                            <span class="fe fe-clock"></span>
                                            <time datetime="2018-05-24"><?php echo e(\Carbon\Carbon::parse($review->created_at)->diffForhumans()); ?></time>
                                        </p>

                                    </div>
                                    <div class="col-auto">

                                        <!-- Dropdown -->
                                        <div class="dropdown">
                                            <a href="#" class="dropdown-ellipses dropdown-toggle" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fe fe-more-vertical"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a href="#!" class="dropdown-item">
                                                    Action
                                                </a>
                                                <a href="#!" class="dropdown-item">
                                                    Another action
                                                </a>
                                                <a href="#!" class="dropdown-item">
                                                    Something else here
                                                </a>
                                            </div>
                                        </div>

                                    </div>
                                </div> <!-- / .row -->
                            </div>
                            <div class="row">
                                <div class="col-md-12">

                                    <div class="rating text-primary " data-rate-value="<?php echo e($review->stars); ?>"></div>

                                    <p class="my-3 font-weight-bold font-italic font-size-lg">
                                        " <?php echo e($review->text); ?>"
                                    </p>
                                </div>
                            </div>
                        </div>

                        <!-- Footer -->
                        <div class="card-footer card-footer-boxed">
                            <a href="<?php echo e(url('business',$review->business['slug'])); ?>">
                                <h4><?php echo e($review->business['name']); ?></h4>
                            </a>
                        </div>
                    </div>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $(".rating").rate({
                update_input_field_name: $(".review_value"),
            });
            $('.carousel').carousel({
                interval: 2000
            })
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wiz_truck\resources\views/backend/review/index.blade.php ENDPATH**/ ?>