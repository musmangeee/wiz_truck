

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
    <nav class="page-breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('permissions.index')); ?>">Permissions</a></li>
            <li class="breadcrumb-item active" aria-current="page">Create Permission</li>
        </ol>
    </nav>
</div>

<div class="row">
    <div class="col-md-12">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-fill-danger" role="alert">
            <?php echo e($error); ?>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h6 class="card-title">Permission Form</h6>
                <form class="forms-sample" method="POST" action="<?php echo e(route('permissions.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="permission_name">Permission Name</label>
                        <input type="text" class="form-control" id="permission_name" autocomplete="off" placeholder="Role Name" name="permission_name">
                    </div>

                    <button type="submit" class="btn btn-primary mr-2">Add Permission</button>
                    <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-light">Cancel</a>
                </form>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wiz_truck\resources\views/admin/permissions/create.blade.php ENDPATH**/ ?>