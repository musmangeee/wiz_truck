


<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('frontend.partials.default_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script type="text/javascript">
      
     $(document).ready(function(){
         $('#BtnCart').click(function(){
             alert('cliecked');
         });

     });

</script>


    <section style="margin-top:9rem;">
        
        <div style="
        background-image: url(<?php echo e(asset('public/business_images/'.$business->images[0]['name'])); ?>);
        height: 230px;
        width:100%;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;"></div>
        
        

        <div class="container mt-5">
            <div class="row" >
                <div class="col-md-8"  style="position:relative">
                  
                    <h1 class="header-title business-title mb-0"><?php echo e($business->name); ?>

                        <?php if($business->status != 0): ?>
                            <a href="" class="text-secondary h4 font-weight-light">Claimed</a>
                        <?php else: ?>
                            <a href="" class="text-secondary h4 font-weight-light" data-toggle="tooltip"
                               data-placement="top"
                               title="This business has not yet been claimed by the owner or a representative."><i
                                        class="fa fa-info-circle pr-1"></i>Unclaimed</a>
                        <?php endif; ?>
                    </h1>
                    <div class="row">
                        <div class="col-auto">
                            <a href="<?php echo e(url('write_a_review/'. $business->id)); ?>">
                                <div class="rating text-primary "
                                     data-rate-value="<?php if(sizeof($business->reviews) > 1): ?><?php echo e(floor((($business->reviews->sum('stars')/sizeof($business->reviews))*2)/2 )); ?> <?php else: ?> 0 <?php endif; ?>"></div>
                            </a>
                        </div>
                        <div class="col text-secondary total-reviews">
                            <?php echo e(sizeof($business->reviews)); ?> Reviews Total
                        </div>
                    </div>

                    <?php $__currentLoopData = $business->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class="badge badge-secondary "><?php echo e($category->name); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br>
                    <br>



                    <div style="position: relative;">
                        
                    <div class="row align-items-center position-sticky">
                        <div class="col">
                
                            <!-- Nav -->
                            <ul class="nav nav-tabs nav-overflow header-tabs">
                                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item">
                                    <a href="#menu_<?php echo e($key); ?>" class="nav-link">
                                        <?php echo e($menu->name); ?>

                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </ul>
                
                        </div>
                    </div>
                    </div>

                     <br/>
                     <br/>
                     <div data-spy="scroll">
                     
                     <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                     <div id="menu_<?php echo e($key); ?>">
                        <h2><?php echo e($menu->name); ?></h2>
                        <div class="row">
                            <?php $__currentLoopData = $menu->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-6">
                              <div class="card">
                                <div class="card-body">
                                  <div class="row">
                                   <div class="col-9">     
                                     <h3 class="card-title mb-1"><?php echo e($product->name); ?></h3>
                                     <small class="card-text text-secondary mb-2"><?php echo e($product->description); ?></small>
                                     <h4 class="card-title">$<?php echo e($product->price); ?></h4>
                                    
                                     <a href="" class="btn btn-sm btn-secondary" id="BtnCart" >Add To Cart</a>
                                     
                                    </div>
                                     <div class="col-3">
                                     <img height="60px" width="60px" src="<?php echo e(asset('public/business_product').'/'.$product->image); ?>">
                                    
                                    </div>
                                  </div>
                                  
                                </div>
                              </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                     </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                      
                        
                   

                   
                   
                    <?php $__currentLoopData = $business->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card">
                            <div class="card-body">

                                <!-- Header -->
                                <div class="mb-3">
                                    <div class="row align-items-center">
                                        <div class="col-auto">

                                            <!-- Avatar -->
                                            <a href="<?php echo e(url('user', $review->user['id'])); ?>" class="avatar">
                                                <img src="<?php echo e(asset('backend/assets/img/avatars/profiles/avatar-1.jpg')); ?>"
                                                     alt="..." class="avatar-img rounded-circle">
                                            </a>

                                        </div>
                                        <div class="col ml-n2">

                                            <a href="<?php echo e(url('user', $review->user['id'])); ?>">
                                                <!-- Title -->
                                                <h4 class="mb-1">
                                                    <?php echo e($review->user['name']); ?>

                                                </h4>
                                            </a>
                                            <!-- Time -->
                                            <p class="card-text small text-muted">
                                                <span class="fe fe-clock"></span>
                                                <time datetime="2018-05-24"><?php echo e(\Carbon\Carbon::parse($review->created_at)->diffForhumans()); ?></time>
                                            </p>

                                        </div>
                                        <div class="col-auto">

                                            <div class="rating text-primary "
                                                 data-rate-value="<?php echo e($review->stars); ?>"></div>

                                        </div>
                                    </div> <!-- / .row -->
                                </div>

                                <!-- Text -->

                                <p class="my-3">
                                    " <?php echo e($review->text); ?>"
                                </p>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-4 mt-n5">
                    <div class="sticky-top pt-5">
                        <div class="card">
                            <div class="card-body">

                                <!-- List group -->
                                <div class="list-group list-group-flush my-n3">
                                    <div class="list-group-item">
                                        <div class="row align-items-center">
                                            <div class="col">

                                                <!-- Title -->
                                                <h5 class="mb-0">
                                                    <i class="fa fa-external-link"></i>
                                                </h5>

                                            </div>
                                            <div class="col-auto">

                                                <a href="<?php echo e($business->url); ?>" target="_blank">
                                                    <?php echo e($business->url); ?>

                                                </a>


                                            </div>
                                        </div> <!-- / .row -->
                                    </div>
                                    <div class="list-group-item">
                                        <div class="row align-items-center">
                                            <div class="col">

                                                <!-- Title -->
                                                <h5 class="mb-0">
                                                    <i class="fa fa-phone"></i>
                                                </h5>

                                            </div>
                                            <div class="col-auto">

                                                <!-- Time -->
                                                <a href="tel:<?php echo e($business->phone); ?>" class="small text-muted">
                                                    <?php echo e($business->phone); ?>

                                                </a>

                                            </div>
                                        </div> <!-- / .row -->
                                    </div>
                                    <div class="list-group-item">
                                        <div class="row align-items-center">
                                            <div class="col">

                                                <!-- Title -->
                                                <h5 class="mb-0">
                                                    <i class="fa fa-store"></i>
                                                </h5>

                                            </div>
                                            <div class="col-auto">


                                                <!-- Time -->
                                                <time class="small text-muted" datetime="1988-10-24">
                                                    <?php echo e(\Carbon\Carbon::parse($business->created_at)->diffForhumans()); ?>

                                                </time>

                                            </div>
                                        </div> <!-- / .row -->
                                    </div>
                                </div>

                            </div>
                        </div>
                        <?php if($business->status == 0): ?>
                            <div class="card">
                                <div class="card-body text-center">
                                    <i class="h1 fa fa-store-alt text-primary"></i>
                                    <h4>Is this your business?</h4>
                                    <p>Claim your business to immediately update business information, respond to
                                        reviews, and more!</p>
                                    <a href="<?php echo e(url('claim_business', $business->slug)); ?>" class="btn btn-white">
                                        Claim This Business
                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>
    </section>


<?php $__env->stopSection(); ?>
<!-- Libs JS -->
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wiz_truck\resources\views/frontend/business.blade.php ENDPATH**/ ?>