

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-12 col-lg-10 col-xl-8">

            <!-- Header -->
            <div class="header mt-md-5">
                <div class="header-body">
                    <div class="row align-items-center">
                        <div class="col">

                            <!-- Pretitle -->
                            <h6 class="header-pretitle">
                                Product
                            </h6>

                            <!-- Title -->
                            <h1 class="header-title">
                               Update Product
                            </h1>

                        </div>
                    </div> <!-- / .row -->
                </div>
            </div>
            <?php if(Session::has('success')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
            <?php endif; ?>
            <?php if(Session::has('error')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
            <?php endif; ?>

            <!-- Form -->
            <form role="form" action="<?php echo e(route('products.update',$product->id)); ?>" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="_method" value="PUT">
                <?php echo csrf_field(); ?>

                <!-- Project name -->
                <div class="form-group">

                    <!-- Label  -->
                    <label>
                        Product name
                    </label>

                    <!-- Input -->
                    <input type="text" name="name" value="<?php echo e($product->name); ?>" class="form-control">

                </div>
                <div class="form-group">

                    <!-- Label  -->
                    <label>
                        Product Description
                    </label>

                    <!-- Input -->
                    <input type="text" name="description" value="<?php echo e($product->description); ?>" class="form-control">

                </div>
                <div class="form-group">

                    <!-- Label  -->
                    <label>
                        Product Price
                    </label>

                    <!-- Input -->
                    <input type="text" name="price" value="<?php echo e($product->price); ?>" class="form-control">

                </div>
                <div class="form-group">

                    <!-- Label  -->
                    <label>
                        Product Discount
                    </label>

                    <!-- Input -->
                    <input type="text" name="discount" value="<?php echo e($product->discount); ?>" class="form-control">

                </div>
                <div class="form-group">
                   
                    <!-- Label  -->
                    <label> 
                        Preview Image
                    </label>

                    <!-- Input -->
                    <br/>
                    <img height="60px" src=" <?php echo e(asset('public\business_product/'. $product->image)); ?>"/>

                </div>
                <div class="form-group">
                   
                    <!-- Label  -->
                    <label>
                        Product Image
                    </label>

                    <!-- Input -->
                    <input type="file" name="image" value="<?php echo e($product->image); ?>" class="form-control">

                </div>

                <!-- Divider -->
                <hr class="mt-5 mb-5">

                <!-- Buttons -->
                <input type="submit" name="submit" value="Update Category" class="btn btn-block btn-primary">

                
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-block btn-link text-muted">
                    Cancel this Category
                </a>

            </form>

        </div>
    </div> <!-- / .row -->
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.business', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wiz_truck\resources\views/business/product/edit.blade.php ENDPATH**/ ?>