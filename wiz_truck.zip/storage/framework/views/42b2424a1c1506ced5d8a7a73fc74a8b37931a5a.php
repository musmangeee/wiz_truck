

<?php $__env->startSection('content'); ?>


    <div class="header">
        <div class="container">

            <!-- Body -->
            <div class="header-body">
                <div class="row align-items-end">
                    <div class="col">

                        <!-- Pretitle -->
                        <h6 class="header-pretitle">
                            Overview
                        </h6>

                        <!-- Title -->
                        <h1 class="header-title">
                            Business Review
                        </h1>

                    </div>
                    
                </div> <!-- / .row -->
            </div> <!-- / .header-body -->

        </div>
    </div>

    <!-- CARDS -->
    <div class="container-fluid">
        

        <div class="card">
            <div class="card-body">
                <table class="table table-sm table-nowrap">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">User</th>
                        <th scope="col">Business</th>
                        <th scope="col">Review</th>
                        <th scope="col">Rate</th>
                        <th scope="col">Updated</th>
                        <th scope="col">Created</th>
                        <th scope="col">Action</th>
                       
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <th><?php echo e($r->user->name ??""); ?></th> 
                            <th> <?php echo e($r->business->name ??""); ?></th>
                            <th><span  class="text-wrap"><?php echo e($r->text); ?></span>
                                </th> 
                            <th><?php echo e($r->stars); ?></th> 
                            <th><?php echo e($r->updated_at); ?></th> 
                            <td><?php echo e(\Carbon\Carbon::parse($r->created_at)->diffForhumans()); ?></td>

                            <td>
                                <a href="<?php echo e(route('businessreview.edit', $r->id)); ?>"
                                   class="btn btn-warning btn-sm lift"><i class="fe fe-edit"></i></a>
                                <form action="<?php echo e(route('dltReviews', $r->id)); ?>" method="post"
                                      class="d-inline-block">
                                    <?php echo csrf_field(); ?>
                                   
                                    <button class="btn btn-danger btn-sm lift   " type="submit"><i class="fe fe-trash"></i>
                                    </button>
                                </form>
                            </td>
                            </tr>

                            
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                 <?php echo e($review->links()); ?>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Work\Wiz_truck\wiz_truck\resources\views/admin/business/reviews.blade.php ENDPATH**/ ?>