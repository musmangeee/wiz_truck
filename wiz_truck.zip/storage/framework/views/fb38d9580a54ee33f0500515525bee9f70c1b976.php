

<?php $__env->startSection('content'); ?>

    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <nav class="page-breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="role">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Permissions</li>
            </ol>
        </nav>
        <div class="d-flex align-items-center flex-wrap text-nowrap">
            <a href="<?php echo e(route('permissions.create')); ?>" class="btn btn-primary btn-icon-text">
                <i class="btn-icon-prepend" data-feather="plus"></i>
                Create New Permission
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <?php if(session()->get('success')): ?>
                <div class="alert alert-fill-success mb-3">
                    <?php echo e(session()->get('success')); ?>

                </div><br/>
            <?php endif; ?>
        </div>
        <div class="col-md-12 grid-margin stretch-card">

            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Permissions</h6>
                    <p class="card-description">All the permissions are listed here.</p>
                    <div class="table-responsive pt-3">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>
                                    #
                                </th>
                                <th>
                                    Permission Name
                                </th>
                                <th>
                                    Created At
                                </th>
                                <th>
                                    Updated At
                                </th>
                                <th>
                                    Actions
                                </th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($permission->id); ?>

                                    </td>
                                    <td>
                                        <?php echo e($permission->name); ?>

                                    </td>

                                    <td>
                                        <?php echo e(\Carbon\Carbon::parse($permission->created_at)->diffForhumans()); ?>

                                    </td>
                                    <td>
                                        <?php echo e(\Carbon\Carbon::parse($permission->updated_at)->diffForhumans()); ?>

                                    </td>
                                    <td>
                                        <form class="d-inline-block" action="<?php echo e(route('permissions.destroy',$permission->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn social-btn btn-danger btn-xs">
                                                <i class="mdi mdi-delete-empty"></i>
                                            </button>
                                        </form>
                                        <a href="<?php echo e(route('permissions.edit',$permission->id)); ?>" class="btn social-btn btn-warning btn-xs">
                                            <i class="mdi mdi-pencil"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wiz_truck\resources\views/admin/permissions/index.blade.php ENDPATH**/ ?>