<!doctype html>
<html lang="en">

<!-- Mirrored from dashkit.goodthemes.co/sign-up.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 12 May 2020 10:14:21 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<?php echo $__env->make('backend.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="d-flex align-items-center bg-auth border-top border-top-2 border-primary">

    <!-- CONTENT
    ================================================== -->
    <div class="container-fluid">
        <div class="row align-items-center justify-content-center">
          <div class="col-12 col-md-5 col-lg-6 col-xl-4 px-lg-6 my-5">
                
            <!-- Heading -->
            <h1 class="display-4 text-center mb-3">
              Sign up
            </h1>
            
            <!-- Subheading -->
            <p class="text-muted text-center mb-5">
              Free access to our dashboard.
            </p>
  
            <form method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>
                 <div class="form-group">

                     <!-- Label -->
                     <label>
                        Name
                     </label>

                     <!-- Input -->
                     <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus placeholder="Enter full name">

                     <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <span class="invalid-feedback" role="alert">
                         <strong><?php echo e($message); ?></strong>
                     </span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                 </div>

                <!-- Email address -->
                <div class="form-group">

                    <!-- Label -->
                    <label>
                        Email Address
                    </label>

                    <!-- Input -->
                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Enter email">

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <!-- Password -->
                <div class="form-group">

                    <!-- Label -->
                    <label>
                        Password
                    </label>

                    <!-- Input group -->
                    <div class="input-group input-group-merge">

                        <!-- Input -->
                        <input type="password" class="form-control form-control-appended" name="password" placeholder="Enter your password">

                        <!-- Icon -->
                        <div class="input-group-append">
                            <span class="input-group-text">
                                <i class="fe fe-eye"></i>
                            </span>
                        </div>

                    </div>
                </div>
                <div class="form-group">

                    <!-- Label -->
                    <label>
                        Confirm Password
                    </label>

                    <!-- Input group -->
                    <div class="input-group input-group-merge">

                        <!-- Input -->
                       <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password" placeholder="Enter confirm password">


                        <!-- Icon -->
                        

                    </div>
                </div>

                <!-- Submit -->
                <button class="btn btn-lg btn-block btn-primary mb-3">
                    Sign up
                </button>

                <!-- Link -->
                <div class="text-center">
                    <small class="text-muted text-center">
                        Already have an account? <a href="<?php echo e(route('login')); ?>">Log in</a>.
                    </small>
                </div>

            </form>
  
          </div>
          <div class="col-12 col-md-7 col-lg-6 col-xl-8 d-none d-lg-block">
            
            <!-- Image -->
            <div class="bg-cover vh-100 mt-n1 mr-n3" style="background-image: url(../backend/assets/img/covers/auth-side-cover.jpg);"></div>
  
          </div>
        </div> <!-- / .row -->
      </div>

    <!-- JAVASCRIPT
    ================================================== -->
    <!-- Libs JS -->
   <?php echo $__env->make('backend.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>


</html>








<?php /**PATH C:\xampp\htdocs\wiz_truck\resources\views/backend/business/Auth/riddersignup.blade.php ENDPATH**/ ?>