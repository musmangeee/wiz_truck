<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\wiz_truck\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>