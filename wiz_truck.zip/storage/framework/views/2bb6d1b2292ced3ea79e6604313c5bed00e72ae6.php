


<?php $__env->startSection('style'); ?>
    <style>
        .list-group-item.active {
            z-index: 2;
            color: #fff;
            background-color: #d32323 !important;
            border-color: #d32323 !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('frontend.partials.default_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="header">

        <!-- Image -->
        <img src="<?php echo e(asset('backend/assets/img/covers/profile-cover-1.jpg')); ?>" class="header-img-top" alt="...">

        <div class="container">

            <!-- Body -->
            <div class="header-body mt-n5 mt-md-n6">
                <div class="row align-items-end">
                    <div class="col-auto">

                        <!-- Avatar -->
                        <div class="avatar avatar-xxl header-avatar-top">
                            <img src="<?php if(auth()->user()->avatar): ?> <?php echo e(auth()->user()->avatar); ?> <?php else: ?> <?php echo e(asset('backend/assets/img/avatars/profiles/avatar-1.jpg')); ?> <?php endif; ?>" alt="..." class="avatar-img rounded-circle border border-4 border-body">
                        </div>

                    </div>
                    <div class="col mb-3 ml-n3 ml-md-n2">

                        <!-- Pretitle -->
                        <h6 class="header-pretitle">
                            Members
                        </h6>

                        <!-- Title -->
                        <h1 class="header-title">
                            <?php echo e(Auth::user()->name); ?>

                        </h1>

                    </div>
                </div> <!-- / .row -->
            </div> <!-- / .header-body -->

        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-12">

                <div class="row">
                    <div class="col-4">
                        <div class="list-group" id="list-tab" role="tablist">
                            <a class="list-group-item list-group-item-action active" id="list-home-list" data-toggle="list" href="#list-home" role="tab" aria-controls="home"><i class="fa fa-user pr-3"></i>Account Information</a>
                            <a class="list-group-item list-group-item-action" id="list-profile-list" data-toggle="list" href="#list-profile" role="tab" aria-controls="profile"><i class="fa fa-key pr-3"></i> Password</a>
                        </div>
                    </div>
                    <div class="col-8">
                        <div class="card">
                            <div class="card-body">
                                <div class="tab-content" id="nav-tabContent">
                                    <div class="tab-pane fade show active" id="list-home" role="tabpanel" aria-labelledby="list-home-list">
                                        <form action="<?php echo e(route('setting.update')); ?>" method="POST">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="">Name</label>
                                                        <input type="text" name="name" class="form-control" value="<?php echo e(Auth::user()->name); ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="">Email</label>
                                                        <input type="text" name="email" class="form-control" value="<?php echo e(Auth::user()->email); ?>">
                                                    </div>
                                                </div>
                                                
                                                   
                                               
                                                
                                                <div class="col-md-12">
                                                    <button class="btn btn-primary w-100" type="submit">Updated Profile</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="tab-pane fade" id="list-profile" role="tabpanel" aria-labelledby="list-profile-list">
                                        <form action="">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="">Current Password</label>
                                                        <input type="text" class="form-control" value="">
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="">New Password</label>
                                                        <input type="text" class="form-control" value="">
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="">Enter Password Again</label>
                                                        <input type="text" class="form-control" value="">
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="col-md-12">
                                                <button class="btn btn-primary w-100" type="submit">Updated Password</button>
                                            </div>

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div> <!-- / .row -->
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Work\Wiz_truck\wiz_truck\resources\views/backend/profile/edit.blade.php ENDPATH**/ ?>