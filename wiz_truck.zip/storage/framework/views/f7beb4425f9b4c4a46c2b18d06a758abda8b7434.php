<nav class="navbar navbar-vertical navbar-vertical-sm fixed-left navbar-expand-md navbar-light" id="sidebarSmall">
    <div class="container">

        <!-- Toggler -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidebarSmallCollapse" aria-controls="sidebarSmallCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Brand -->
        <a class="navbar-brand" href="./index.html">
            <img src="./assets/img/logo.svg" class="navbar-brand-img
          mx-auto" alt="...">
        </a>

        <!-- User (xs) -->
        <div class="navbar-user d-md-none">

            <!-- Dropdown -->
            <div class="dropdown">

                <!-- Toggle -->
                <a href="#" id="sidebarSmallIcon" class="dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <div class="avatar avatar-sm avatar-online">
                        <img src="./assets/img/avatars/profiles/avatar-1.jpg" class="avatar-img rounded-circle" alt="...">
                    </div>
                </a>

                <!-- Menu -->
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="sidebarSmallIcon">
                    <a href="./profile-posts.html" class="dropdown-item">Profile</a>
                    <a href="./account-general.html" class="dropdown-item">Settings</a>
                    <hr class="dropdown-divider">
                    <a href="./sign-in.html" class="dropdown-item">Logout</a>
                </div>

            </div>

        </div>

        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidebarSmallCollapse">

            <!-- Form -->
            <form class="mt-4 mb-3 d-md-none">
                <div class="input-group input-group-rounded input-group-merge">
                    <input type="search" class="form-control form-control-rounded form-control-prepended" placeholder="Search" aria-label="Search">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                            <span class="fe fe-search"></span>
                        </div>
                    </div>
                </div>
            </form>

            <!-- Divider -->
            <hr class="navbar-divider d-none d-md-block mt-0 mb-3">

            <!-- Navigation -->
            <ul class="navbar-nav">
                <li class="nav-item dropright">
                    <a class="nav-link dropdown-toggle active" id="sidebarSmallDashboards" href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" title="Dashboards">
                        <i class="fe fe-home"></i> <span class="d-md-none">Dashboards</span>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="sidebarSmallDashboards">
                        <li class="dropdown-header d-none d-md-block">
                            <h6 class="text-uppercase mb-0">Dashboards</h6>
                        </li>
                        <li>
                            <a href="./index.html" class="dropdown-item active">
                                Default
                            </a>
                        </li>
                        <li>
                            <a href="./dashboard-project-management.html" class="dropdown-item ">
                                Project Management
                            </a>
                        </li>
                        <li>
                            <a href="./dashboard-ecommerce.html" class="dropdown-item ">
                                E-Commerce
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropright">
                    <a class="nav-link dropdown-toggle " id="sidebarSmallPages" href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                        <i class="fe fe-file"></i> <span class="d-md-none">Pages</span>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="sidebarSmallPages">
                        <li class="dropdown-header d-none d-md-block">
                            <h6 class="text-uppercase mb-0">Pages</h6>
                        </li>
                        <li class="dropright">
                            <a class="dropdown-item dropdown-toggle " href="#" id="sidebarSmallProfile" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Profile
                            </a>
                            <div class="dropdown-menu" aria-labelledby="sidebarSmallProfile">
                                <a class="dropdown-item " href="./profile-posts.html">
                                    Posts
                                </a>
                                <a class="dropdown-item " href="./profile-groups.html">
                                    Groups
                                </a>
                                <a class="dropdown-item " href="./profile-projects.html">
                                    Projects
                                </a>
                                <a class="dropdown-item " href="./profile-files.html">
                                    Files
                                </a>
                                <a class="dropdown-item " href="./profile-subscribers.html">
                                    Subscribers
                                </a>
                            </div>
                        </li>
                        <li class="dropright">
                            <a class="dropdown-item dropdown-toggle " href="#" id="sidebarSmallProject" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Project
                            </a>
                            <div class="dropdown-menu" aria-labelledby="sidebarSmallProject">
                                <a class="dropdown-item " href="./project-overview.html">
                                    Overview
                                </a>
                                <a class="dropdown-item " href="./project-files.html">
                                    Files
                                </a>
                                <a class="dropdown-item " href="./project-reports.html">
                                    Reports
                                </a>
                                <a class="dropdown-item " href="./project-new.html">
                                    New project
                                </a>
                            </div>
                        </li>
                        <li class="dropright">
                            <a class="dropdown-item dropdown-toggle " href="#" id="sidebarSmallTeam" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Team
                            </a>
                            <div class="dropdown-menu" aria-labelledby="sidebarSmallTeam">
                                <a class="dropdown-item " href="./team-overview.html">
                                    Overview
                                </a>
                                <a class="dropdown-item " href="./team-projects.html">
                                    Projects
                                </a>
                                <a class="dropdown-item " href="./team-members.html">
                                    Members
                                </a>
                                <a class="dropdown-item " href="./team-new.html">
                                    New team
                                </a>
                            </div>
                        </li>
                        <li class="dropright">
                            <a class="dropdown-item dropdown-toggle " href="#" id="sidebarSmallFeed" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Feed
                            </a>
                            <div class="dropdown-menu" aria-labelledby="sidebarSmallFeed">
                                <a class="dropdown-item " href="./feed.html">
                                    Platform
                                </a>
                                <a class="dropdown-item " href="./social-feed.html">
                                    Social
                                </a>
                            </div>
                        </li>
                        <li class="dropright">
                            <a class="dropdown-item dropdown-toggle " href="#" id="sidebarSmallAccount" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Account
                            </a>
                            <div class="dropdown-menu" aria-labelledby="sidebarSmallAccount">
                                <a class="dropdown-item " href="./account-general.html">
                                    General
                                </a>
                                <a class="dropdown-item " href="./account-billing.html">
                                    Billing
                                </a>
                                <a class="dropdown-item " href="./account-members.html">
                                    Members
                                </a>
                                <a class="dropdown-item " href="./account-security.html">
                                    Security
                                </a>
                                <a class="dropdown-item " href="./account-notifications.html">
                                    Notifications
                                </a>
                            </div>
                        </li>
                        <li class="dropright">
                            <a class="dropdown-item dropdown-toggle " href="#" id="sidebarSmallCrm" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                CRM
                            </a>
                            <div class="dropdown-menu" aria-labelledby="sidebarSmallCrm">
                                <a class="dropdown-item " href="./crm-contacts.html">
                                    Contacts
                                </a>
                                <a class="dropdown-item " href="./crm-companies.html">
                                    Companies
                                </a>
                                <a class="dropdown-item " href="./crm-deals.html">
                                    Deals
                                </a>
                            </div>
                        </li>
                        <li>
                            <a class="dropdown-item " href="./wizard.html">
                                Wizard
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item " href="./kanban.html">
                                Kanban
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item " href="./orders.html">
                                Orders
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item " href="./invoice.html">
                                Invoice
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item " href="./pricing.html">
                                Pricing
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item" data-toggle="tooltip" data-placement="right" data-template="<div class=&quot;tooltip d-none d-md-block&quot; role=&quot;tooltip&quot;><div class=&quot;arrow&quot;></div><div class=&quot;tooltip-inner&quot;></div></div>" title="" data-original-title="Widgets">
                    <a class="nav-link " href="./widgets.html">
                        <i class="fe fe-grid"></i> <span class="d-md-none">Widgets</span>
                    </a>
                </li>
                <li class="nav-item dropright">
                    <a class="nav-link dropdown-toggle" id="sidebarSmallAuth" href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                        <i class="fe fe-user"></i> <span class="d-md-none">Auth</span>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="sidebarSmallAuth">
                        <li class="dropdown-header d-none d-md-block">
                            <h6 class="text-uppercase mb-0">Authentication</h6>
                        </li>
                        <li class="dropright">
                            <a class="dropdown-item dropdown-toggle" href="#" id="sidebarSmallSignIn" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Sign in
                            </a>
                            <div class="dropdown-menu" aria-labelledby="sidebarSmallSignIn">
                                <a class="dropdown-item" href="./sign-in-cover.html">
                                    Cover
                                </a>
                                <a class="dropdown-item" href="./sign-in-illustration.html">
                                    Illustration
                                </a>
                                <a class="dropdown-item" href="./sign-in-basics.html">
                                    Basic
                                </a>
                            </div>
                        </li>
                        <li class="dropright">
                            <a class="dropdown-item dropdown-toggle" href="#" id="sidebarSmallSignUp" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Sign up
                            </a>
                            <div class="dropdown-menu" aria-labelledby="sidebarSmallSignUp">
                                <a class="dropdown-item" href="./sign-up-cover.html">
                                    Cover
                                </a>
                                <a class="dropdown-item" href="./sign-up-illustration.html">
                                    Illustration
                                </a>
                                <a class="dropdown-item" href="./sign-up.html">
                                    Basic
                                </a>
                            </div>
                        </li>
                        <li class="dropright">
                            <a class="dropdown-item dropdown-toggle" href="#" id="sidebarSmallPassword" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Password reset
                            </a>
                            <div class="dropdown-menu" aria-labelledby="sidebarSmallPassword">
                                <a class="dropdown-item" href="./password-reset-cover.html">
                                    Cover
                                </a>
                                <a class="dropdown-item" href="./password-reset-illustration.html">
                                    Illustration
                                </a>
                                <a class="dropdown-item" href="./password-reset.html">
                                    Basic
                                </a>
                            </div>
                        </li>
                        <li class="dropright">
                            <a class="dropdown-item dropdown-toggle" href="#" id="sidebarSmallError" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Error
                            </a>
                            <div class="dropdown-menu" aria-labelledby="sidebarSmallError">
                                <a class="dropdown-item" href="./error-illustration.html">
                                    Illustration
                                </a>
                                <a class="dropdown-item" href="./error.html">
                                    Basic
                                </a>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="nav-item d-md-none">
                    <a class="nav-link" href="#sidebarModalActivity" data-toggle="modal">
                        <span class="fe fe-bell"></span> Notifications
                    </a>
                </li>
            </ul>

            <!-- Divider -->
            <hr class="navbar-divider my-3">

            <!-- Navigation -->
            <ul class="navbar-nav mb-md-4">
                <li class="nav-item dropright">
                    <a class="nav-link dropdown-toggle " id="sidebarSmallBasics" href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" title="Basics">
                        <i class="fe fe-clipboard"></i> <span class="d-md-none">Basics</span>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="sidebarSmallBasics">
                        <li class="dropdown-header d-none d-md-block">
                            <h6 class="text-uppercase mb-0">Basics</h6>
                        </li>
                        <li>
                            <a href="./docs/getting-started.html" class="dropdown-item ">
                                Getting Started
                            </a>
                        </li>
                        <li>
                            <a href="./docs/design-file.html" class="dropdown-item ">
                                Design File
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="./docs/components.html" data-toggle="tooltip" data-placement="right" data-template="<div class=&quot;tooltip d-none d-md-block&quot; role=&quot;tooltip&quot;><div class=&quot;arrow&quot;></div><div class=&quot;tooltip-inner&quot;></div></div>" title="" data-original-title="Components">
                        <i class="fe fe-book-open"></i> <span class="d-md-none">Components</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="./docs/changelog.html" data-toggle="tooltip" data-placement="right" data-template="<div class=&quot;tooltip d-none d-md-block&quot; role=&quot;tooltip&quot;><div class=&quot;arrow&quot;></div><div class=&quot;tooltip-inner&quot;></div></div>" title="" data-original-title="Changelog">
                        <i class="fe fe-git-branch"></i> <span class="d-md-none">Changelog</span> <span class="badge badge-primary ml-auto d-md-none">v1.6.0</span>
                    </a>
                </li>
            </ul>

            <!-- Push content down -->
            <div class="mt-auto"></div>


            <!-- Customize -->
            <div class="mb-4" data-toggle="tooltip" data-placement="right" data-template="<div class=&quot;tooltip d-none d-md-block&quot; role=&quot;tooltip&quot;><div class=&quot;arrow&quot;></div><div class=&quot;tooltip-inner&quot;></div></div>" title="" data-original-title="Customize">
                <a href="#modalDemo" class="btn btn-block btn-primary" data-toggle="modal">
                    <i class="fe fe-sliders"></i> <span class="d-md-none ml-2">Customize</span>
                </a>
            </div>



            <!-- User (md) -->
            <div class="navbar-user d-none d-md-flex flex-column" id="sidebarSmallUser">

                <!-- Icon -->
                <a href="#sidebarModalSearch" class="navbar-user-link mb-3" data-toggle="modal">
              <span class="icon">
                <i class="fe fe-search"></i>
              </span>
                </a>

                <!-- Icon -->
                <a href="#sidebarModalActivity" class="navbar-user-link mb-3" data-toggle="modal">
              <span class="icon">
                <i class="fe fe-bell"></i>
              </span>
                </a>

                <!-- Dropup -->
                <div class="dropright">

                    <!-- Toggle -->
                    <a href="#" id="sidebarSmallIconCopy" class="dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <div class="avatar avatar-sm avatar-online">
                            <img src="./assets/img/avatars/profiles/avatar-1.jpg" class="avatar-img rounded-circle" alt="...">
                        </div>
                    </a>

                    <!-- Menu -->
                    <div class="dropdown-menu" aria-labelledby="sidebarSmallIconCopy">
                        <a href="./profile-posts.html" class="dropdown-item">Profile</a>
                        <a href="./account-general.html" class="dropdown-item">Settings</a>
                        <hr class="dropdown-divider">
                        <a href="./sign-in.html" class="dropdown-item">Logout</a>
                    </div>

                </div>

            </div>


        </div> <!-- / .navbar-collapse -->

    </div>
</nav><?php /**PATH C:\laragon\www\Work\Wiz_truck\wiz_truck\resources\views/backend/partials/sidebar_small.blade.php ENDPATH**/ ?>