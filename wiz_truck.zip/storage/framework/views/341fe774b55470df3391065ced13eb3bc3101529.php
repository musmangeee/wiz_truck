

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="header">
            <div class="container-fluid">

                <!-- Body -->
                <div class="header-body">
                    <div class="row align-items-end">
                        <div class="col">

                            <!-- Pretitle -->
                            <h6 class="header-pretitle">
                                Overview
                            </h6>

                            <!-- Title -->
                            <h1 class="header-title">
                               Events
                            </h1>

                        </div>
                       
                    </div> <!-- / .row -->
                </div> <!-- / .header-body -->

            </div>
        </div>
       

        <div class="card">
            <div class="card-body">

                <!-- Table -->
                <div class="table-responsive">
                    <table class="table table-sm table-nowrap card-table text-secondary">
                        <thead>
                        <tr>
                           
                            <th>Business</th>
                            <th>User</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Status</th>
                        </tr>
                        </thead>
                        <tbody>
                      
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                               <td>
                                <?php echo e($e->restaurant->name); ?>

                               </td>
                               <td>
                                <?php echo e($e->user->name); ?>

                            </td>
                            <td>
                                <?php echo e(\Carbon\Carbon::parse($e->start_date)->diffForhumans()); ?>

                            </td>
                            <td>
                                <?php echo e(\Carbon\Carbon::parse($e->end_date)->diffForhumans()); ?>

                            </td>
                            <td>
                                <?php echo e(\Carbon\Carbon::parse($e->start_time)->diffForhumans()); ?>

                                
                            </td>
                            <td>
                                <?php echo e($e->end_time); ?>

                            </td>
                            <td>
                                <span class="badge badge-primary"><?php echo e($e->status); ?></span>
                            </td>
                           </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($events->links()); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Work\Wiz_truck\wiz_truck\resources\views/admin/Events/index.blade.php ENDPATH**/ ?>