

<?php $__env->startSection('content'); ?>

    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <nav class="page-breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="role">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Users Management</li>
            </ol>
        </nav>
        <div class="d-flex align-items-center flex-wrap text-nowrap">
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary btn-icon-text">
                <i class="btn-icon-prepend" data-feather="plus"></i>
                Create New User
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <?php if(session()->get('success')): ?>
                <div class="alert alert-fill-success mb-3">
                    <?php echo e(session()->get('success')); ?>

                </div><br/>
            <?php endif; ?>
        </div>
        <div class="col-md-12 grid-margin stretch-card">

            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Permissions</h6>
                    <p class="card-description">All the permissions are listed here.</p>
                    <div class="table-responsive pt-3">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>
                                    #
                                </th>
                                <th>
                                    Name
                                </th>
                                <th>
                                    Device Token
                                </th>
                                <th>
                                    Email
                                </th>
                                <th>
                                    Role
                                </th>
                                <th>
                                    Created
                                </th>
                                <th>
                                    Updated
                                </th>
                                <th>
                                    Actions
                                </th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$i); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->device_token); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td>
                                        <?php if(!empty($user->getRoleNames())): ?>
                                            <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <label class="badge badge-success"><?php echo e($v); ?></label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                                    <td><?php echo e($user->updated_at->diffForHumans()); ?></td>

                                    <td>
                                        <form class="d-inline-block" action="<?php echo e(route('users.destroy',$user->id)); ?>"
                                              method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-danger btn-sm lift   " type="submit"><i class="fe fe-trash"></i>
                                            </button>
                                        </form>
                                      
                                        <a href="<?php echo e(route('users.edit',$user->id)); ?>"
                                            class="btn btn-warning btn-sm lift"><i class="fe fe-edit"></i></a>

                                         

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>

                        <?php echo $data->render(); ?>

                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Work\Wiz_truck\wiz_truck\resources\views/admin/users/index.blade.php ENDPATH**/ ?>