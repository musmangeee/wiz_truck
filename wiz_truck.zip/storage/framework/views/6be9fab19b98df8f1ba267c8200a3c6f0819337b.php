

<?php $__env->startSection('content'); ?>


    <div class="header">
        <div class="container">

            <!-- Body -->
            <div class="header-body">
                <div class="row align-items-end">
                    <div class="col">

                        <!-- Pretitle -->
                        <h6 class="header-pretitle">
                            Orders
                        </h6>

                        <!-- Title -->
                        <h1 class="header-title">
                            Orders Management
                        </h1>

                    </div>
                    
                </div> <!-- / .row -->
            </div> <!-- / .header-body -->

        </div>
    </div>

    <!-- CARDS -->
    <div class="container-fluid">
        

        <div class="row">
            <div class="col-3 col-lg-6 col-xl">

                <!-- Value  -->
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
    
                                <!-- Title -->
                                <h6 class="text-uppercase text-muted mb-2">
                                    Pending Orders
                                </h6>
    
                                <!-- Heading -->
                                <span class="h2 mb-0">
                                    <?php echo e($pending_count); ?>

                                </span>
    
                            </div>
                            <div class="col-auto">
    
                                <!-- Icon -->
                                <span class="h2 fe fe-star text-muted mb-0"></span>
    
                            </div>
                        </div>
                        <!-- / .row -->
                    </div>
                </div>
    
            </div>
            <div class="col-3 col-lg-6 col-xl">

                <!-- Value  -->
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
    
                                <!-- Title -->
                                <h6 class="text-uppercase text-muted mb-2">
                                    Accepted Orders
                                </h6>
    
                                <!-- Heading -->
                                <span class="h2 mb-0">
                                    <?php echo e($accepted_count); ?>

                                </span>
    
                            </div>
                            <div class="col-auto">
    
                                <!-- Icon -->
                                <span class="h2 fe fe-star text-muted mb-0"></span>
    
                            </div>
                        </div>
                        <!-- / .row -->
                    </div>
                </div>
    
            </div>
            <div class="col-3 col-lg-6 col-xl">

                <!-- Value  -->
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
    
                                <!-- Title -->
                                <h6 class="text-uppercase text-muted mb-2">
                                    Cancle Orders
                                </h6>
    
                                <!-- Heading -->
                                <span class="h2 mb-0">
                                    <?php echo e($cancle_count); ?>

                                </span>
    
                            </div>
                            <div class="col-auto">
    
                                <!-- Icon -->
                                <span class="h2 fe fe-star text-muted mb-0"></span>
    
                            </div>
                        </div>
                        <!-- / .row -->
                    </div>
                </div>
    
            </div>
            <div class="col-3 col-lg-6 col-xl">

                <!-- Value  -->
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
    
                                <!-- Title -->
                                <h6 class="text-uppercase text-muted mb-2">
                                    Deliver Orders
                                </h6>
    
                                <!-- Heading -->
                                <span class="h2 mb-0">
                                    <?php echo e($deliver_count); ?>

                                </span>
    
                            </div>
                            <div class="col-auto">
    
                                <!-- Icon -->
                                <span class="h2 fe fe-star text-muted mb-0"></span>
    
                            </div>
                        </div>
                        <!-- / .row -->
                    </div>
                </div>
    
            </div>
        </div>

        

        <div class="card">
            <div class="card-body">
                <table class="table table-sm table-nowrap">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">User</th>
                        <th scope="col">Business</th>
                        <th scope="col">Order Status</th>
                        <th scope="col">Address</th>
                        <th scope="col">Order Type</th>
                        <th scope="col">Amount</th>
                       
                        <th scope="col">Action</th>
                       
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <th><?php echo e($r->user->name); ?></th> 
                            <th><?php echo e($r->restaurant != null ? $r->restaurant->name : ''); ?></th> 
                            <th><?php echo e($r->status); ?></th>
                            <th><?php echo e($r->address); ?></th>
                            <th><?php echo e($r->order_type); ?></th>
                            <th><?php echo e($r->total); ?></th>
                            <td>
                                <a href="<?php echo e(route('order.edit', $r->id)); ?>"
                                   class="btn btn-warning btn-sm lift"><i class="fe fe-edit"></i></a>
                                <form action="<?php echo e(route('order.destroy', $r->id)); ?>" method="post"
                                      class="d-inline-block">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>   
                                    <button class="btn btn-danger btn-sm lift   " type="submit"><i class="fe fe-trash"></i>
                                    </button>
                                </form>
                            </td>
                            </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($orders->links()); ?>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Work\Wiz_truck\wiz_truck\resources\views/admin/order/index.blade.php ENDPATH**/ ?>