

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-12 col-lg-10 col-xl-8">

            <!-- Header -->
            <div class="header mt-md-5">
                <div class="header-body">
                    <div class="row align-items-center">
                        <div class="col">

                            <!-- Pretitle -->
                            <h6 class="header-pretitle">
                                New City
                            </h6>

                            <!-- Title -->
                            <h1 class="header-title">
                                Create a new City
                            </h1>

                        </div>
                    </div> <!-- / .row -->
                </div>
            </div>
             <?php if(Session::has('success')): ?>
             <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
             <?php endif; ?>
             <?php if(Session::has('error')): ?>
             <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
             <?php endif; ?>

            <!-- Form -->
            <form class="mb-4" method="POST" action="<?php echo e(route('city.store')); ?>" enctype="multipart/form-data">

            <?php echo csrf_field(); ?>
                <!-- Project name -->
                <div class="form-group">

                    <!-- Label  -->
                    <label>
                        City name
                    </label>

                    <!-- Input -->
                    <input type="text" name="name" class="form-control">

                </div>
                <!-- Project name -->
         
                <!-- Divider -->
                <hr class="mt-5 mb-5">

                <!-- Buttons -->
                <input type="submit" name="submit" value="Create City" class="btn btn-block btn-primary">

                
                <a href="<?php echo e(route('city.index')); ?>" class="btn btn-block btn-link text-muted">

                    Cancel this City
                </a>

            </form>

        </div>
    </div> <!-- / .row -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wiz_truck\resources\views/admin/city/create.blade.php ENDPATH**/ ?>