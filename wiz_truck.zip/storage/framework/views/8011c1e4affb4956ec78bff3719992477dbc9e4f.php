


<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('frontend.partials.default_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <h1 class="text-center">Cart Page</h1>
        <div class="row">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th width="50%">Product</th>
                    <th width="10%">Price</th>
                    <th width="8%">Quantity</th>
                    <th width="22%">Sub Total</th>
                    <th width="10%"></th>
                </tr>
                </thead>
                <tbody>
                <?php $total = 0; ?>
                <?php if(session('cart')): ?>
                    <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $sub_total = $product['price'] * $product['quantity'];
                            $total += $sub_total;
                        ?>
                        <tr>
                            <td>
                                
                                <span><?php echo e($product['name']); ?></span>
                            </td>
                            <td>$<?php echo e($product['price']); ?></td>
                            <td><?php echo e($product['quantity']); ?></td>
                            <td>$<?php echo e($sub_total); ?></td>
                            <td>
                                <a href="<?php echo e(route('remove', [$id])); ?>" class="btn btn-danger btn-sm">X</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
                <tfoot>
                <tr>
                    <td>
                        <a href=""
                           class="btn btn-warning"
                        >Continue Shopping</a>
                        

                    </td>
                    <td colspan="2"></td>
                    <td><strong>Total $<?php echo e($total); ?></strong></td>
                </tr>
                </tfoot>
            </table>
        </div>
    </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wiz_truck\resources\views/frontend/cart.blade.php ENDPATH**/ ?>