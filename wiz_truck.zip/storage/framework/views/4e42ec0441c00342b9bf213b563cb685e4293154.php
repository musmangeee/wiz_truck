 <script src="<?php echo e(URL::asset('backend/assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('backend/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('backend/assets/libs/%40shopify/draggable/lib/es5/draggable.bundle.legacy.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('backend/assets/libs/autosize/dist/autosize.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('backend/assets/libs/chart.js/dist/Chart.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('backend/assets/libs/dropzone/dist/min/dropzone.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('backend/assets/libs/flatpickr/dist/flatpickr.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('backend/assets/libs/highlightjs/highlight.pack.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('backend/assets/libs/jquery-mask-plugin/dist/jquery.mask.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('backend/assets/libs/list.js/dist/list.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('backend/assets/libs/quill/dist/quill.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('backend/assets/libs/select2/dist/js/select2.full.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('backend/assets/libs/chart.js/Chart.extension.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('backend/assets/libs/rater/rater.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('backend/assets/libs/image-upload/image-uploader.min.js')); ?>"></script>
 <!-- Map -->
 <script src='../api.mapbox.com/mapbox-gl-js/v0.53.0/mapbox-gl.js'></script>

 <!-- Theme JS -->
 <script src="<?php echo e(URL::asset('backend/assets/js/theme.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('backend/assets/js/dashkit.min.js')); ?>"></script>

<?php /**PATH C:\laragon\www\Work\Wiz_truck\wiz_truck\resources\views/admin/partials/scripts.blade.php ENDPATH**/ ?>