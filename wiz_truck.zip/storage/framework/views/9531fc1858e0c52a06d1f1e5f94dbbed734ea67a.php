

<?php $__env->startSection('style'); ?>
    <style>
        .rating {
            font-size: 1rem;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('frontend.partials.default_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <!-- CARDS -->
    <div class="container mt-5">

        <?php if(Auth::user()->email_verified_at == null): ?>
            <div class="alert alert-secondary" role="alert">
                Looks like you still have to confirm your account. Any reviews you write won’t be posted until you do.
                Check your inbox and spam folders for a confirmation email, or click here to resend.
            </div>
        <?php endif; ?>
            <h2 class="heading text-primary">Been to these businesses recently?</h2>
        <div class="row">
            <?php $__currentLoopData = $city_business; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $business): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card mb-3 lift">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-auto">

                                    <!-- Avatar -->
                                    <a href="<?php echo e(url('business', $business->slug)); ?>" class="avatar avatar-4by3">
                                        <img src="<?php echo e(asset('backend/assets/img/avatars/profiles/avatar-2.jpg')); ?>"
                                             alt="..." class="avatar-img rounded">
                                    </a>

                                </div>
                                <div class="col ml-n2">

                                    <!-- Title -->
                                    <h4 class="mb-1">
                                        <a href="<?php echo e(url('business', $business->slug)); ?>"><?php echo e($business->name); ?></a>
                                    </h4>

                                    <!-- Text -->

                                    <a href="<?php echo e(url('business', $business->slug)); ?>" class="small">
                                        <div class="rating text-primary "
                                             data-rate-value="<?php if(sizeof($business->reviews) > 1): ?><?php echo e(floor((($business->reviews->sum('stars')/sizeof($business->reviews))*2)/2 )); ?> <?php else: ?> 0 <?php endif; ?>"></div>

                                    </a>


                                </div>

                            </div> <!-- / .row -->
                        </div> <!-- / .card-body -->
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- / .row -->

    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wiz_truck\resources\views/backend/review/write_a_review.blade.php ENDPATH**/ ?>