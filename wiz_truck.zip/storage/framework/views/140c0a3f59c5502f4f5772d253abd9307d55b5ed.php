

<?php $__env->startSection('content'); ?>

<!-- HEADER -->
<div class="header">
    <div class="container-fluid">

        <!-- Body -->
        <div class="header-body">
            <div class="row align-items-end">
                <div class="col">

                    <!-- Pretitle -->
                    <h6 class="header-pretitle">
                        Overview
                    </h6>

                    <!-- Title -->
                    <h1 class="header-title">
                        Dashboard
                    </h1>

                </div>

            </div>
            <!-- / .row -->
        </div>
        <!-- / .header-body -->

    </div>
</div>
<!-- / .header -->

<!-- CARDS -->
<div class="container-fluid">
    <div class="row">
        <div class="col-12 col-lg-6 col-xl">

            <!-- Value  -->
            <div class="card">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">

                            <!-- Title -->
                            <h6 class="text-uppercase text-muted mb-2">
                                Total Orders
                            </h6>

                            <!-- Heading -->
                            <span class="h2 mb-0">
                                <?php echo e($order); ?>

                            </span>

                        </div>
                        <div class="col-auto">

                            <!-- Icon -->
                            <span class="h2 fe fe-star text-muted mb-0"></span>

                        </div>
                    </div>
                    <!-- / .row -->
                </div>
            </div>

        </div>
        <div class="col-12 col-lg-6 col-xl">

            <div class="card">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">

                            <!-- Title -->
                            <h6 class="text-uppercase text-muted mb-2">
                                Restaurants
                            </h6>

                            <!-- Heading -->
                            <span class="h2 mb-0">
                                <?php echo e($restaurants); ?>

                            </span>

                        </div>
                        <div class="col-auto">

                            <!-- Icon -->
                            <span class="h2 fe fe-star text-muted mb-0"></span>

                        </div>
                    </div>
                    <!-- / .row -->
                </div>
            </div>

        </div>
        <div class="col-12 col-lg-6 col-xl">

            <div class="card">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">

                            <!-- Title -->
                            <h6 class="text-uppercase text-muted mb-2">
                                Total clients
                            </h6>

                            <!-- Heading -->
                            <span class="h2 mb-0">
                                <?php echo e($clients); ?>

                            </span>

                        </div>
                        <div class="col-auto">

                            <!-- Icon -->
                            <span class="h2 fe fe-star text-muted mb-0"></span>

                        </div>
                    </div>
                    <!-- / .row -->
                </div>
            </div>

        </div>
        <div class="col-12 col-lg-6 col-xl">

            <!-- Time -->
            <div class="card">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">

                            <!-- Title -->
                            <h6 class="text-uppercase text-muted mb-2">
                                Total earnings
                            </h6>

                            <!-- Heading -->
                            <span class="h2 mb-0">
                                <?php echo e($total_sum); ?>

                            </span>

                        </div>
                        <div class="col-auto">

                            <!-- Icon -->
                            <span class="h2 fe fe-star text-muted mb-0"></span>

                        </div>
                    </div>
                    <!-- / .row -->
                </div>
            </div>

        </div>

    </div>

    
    <div class="row">

        <div class="col-lg-6">
            <div class="card">
                <div class="card-header no-border">
                    <h3 class="card-title">Food Truck</h3>
                    <div class="card-tools">
                        <a href="<?php echo e(route('business.index')); ?>" class="btn btn-tool btn-sm"><i class="fa fa-bars"></i>
                        </a>
                    </div>
                </div>
                <div class="card-body p-0">
                    <table class="table table-striped table-valign-middle">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Restaurant</th>
                                <th>Address</th>

                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $business; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    
                                    <img class='img-circle img-size-32 mr-2' style='width:50px'
                                        src='<?php echo e(asset('public/business_images/'.$item->images[0]['name'])); ?>'
                                        alt='restaurant-2649620_1280'>
                                </td>
                                <td><?php echo e($item->name); ?></td>
                                <td>
                                    <?php echo e($item ->address); ?>

                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card">
                <div class="card-header no-border">
                    <h3 class="card-title">Recent Users</h3>
                    <div class="card-tools">
                        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-tool btn-sm"><i class="fa fa-bars"></i>
                        </a>
                    </div>
                </div>
                <div class="card-body p-0">
                    <table class="table table-striped table-valign-middle">
                        <thead>
                            <tr>

                                <th>Name</th>
                                <th>Email</th>
                                <th>Type</th>

                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($item->name); ?></td>
                                <td>
                                    <?php echo e($item ->email); ?>

                                </td>
                                <td>
                                    <span class="badge badge-success"> <?php echo e($item->roles->pluck('name')[0] ??""); ?></span>

                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- / .row -->


    
    <div class="row">

        <div class="col-lg-6">
            <div class="card">
                <div class="card-header no-border">
                    <h3 class="card-title">Recent Orders</h3>
                    <div class="card-tools">
                        <a href="" class="btn btn-tool btn-sm"><i class="fa fa-bars"></i>
                        </a>
                    </div>
                </div>
                <div class="card-body p-0">
                    <table class="table table-striped table-valign-middle">
                        <thead>
                            <tr>
                                <th>#ID</th>
                                <th>Order Type</th>
                                <th>Total</th>
                                <th>Status</th>
                                

                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($item->id); ?></th>
                                <th><?php echo e($item->order_type); ?></th> 
                                
                                    <th><?php echo e($item->total); ?></th>
                               
                                    <th><?php echo e($item->status); ?></th>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>
            </div>
        </div>

       
    </div>

</div>

</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wiz_truck\resources\views/admin/index.blade.php ENDPATH**/ ?>