

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="header">
            <div class="container-fluid">

                <!-- Body -->
                <div class="header-body">
                    <div class="row align-items-end">
                        <div class="col">

                            <!-- Pretitle -->
                            <h6 class="header-pretitle">
                                Overview
                            </h6>

                            <!-- Title -->
                            <h1 class="header-title">
                               Category
                            </h1>

                        </div>
                        <div class="col-auto">

                            <!-- Button -->
                            <a href="<?php echo e(route('business_category.create')); ?>" class="btn btn-primary lift">
                                Create New Category
                            </a>

                        </div>
                    </div> <!-- / .row -->
                </div> <!-- / .header-body -->

            </div>
        </div>
        <?php if(Session::has('success')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">

                <!-- Table -->
                <div class="table-responsive">
                    <table class="table table-sm table-nowrap card-table text-secondary">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Image</th>
                            <th>Category</th>
                            <th>Image</th>
                            <th>Created At</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                            $i = 1;
                        ?>
                        <?php $__currentLoopData = $businessCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($i++); ?></th>
                                <td><i class="<?php echo e($item->icon); ?> pr-3"></i><?php echo e($item->name); ?></td>
                                <td>



                                        <img height="30px" src="<?php echo e(asset('public\business_category/'. $item->image)); ?>" class="avatar avatar-sm rounded">


                                </td>
                                <td><?php echo e($item->created_at); ?></td>
                                <td>
                                    <a href="<?php echo e(route('business_category.edit', $item->id)); ?>"
                                       class="btn btn-warning btn-sm lift"><i class="fe fe-edit"></i></a>
                                    <form action="<?php echo e(route('business_category.destroy', $item->id)); ?>" method="post"
                                          class="d-inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm lift   " type="submit"><i class="fe fe-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wiz_truck\resources\views/admin/category/index.blade.php ENDPATH**/ ?>