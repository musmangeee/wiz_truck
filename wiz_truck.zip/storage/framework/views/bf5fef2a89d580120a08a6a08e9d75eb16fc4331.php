

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.partials.default_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section>
    <div class="container my-5">
        <div class="row">
            <div class="col-md-7">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('search') . '?location=' .$data['pref_location']); ?>"><?php echo e($data['pref_location']); ?></a></li>
                        <?php if($data['keywords'] != ''): ?>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($data['keywords']); ?></li>
                        <?php endif; ?>
                    </ol>
                </nav>
                <?php $__currentLoopData = $data['search_results']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card lift">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-auto">
                                <!-- Avatar -->
                                <a href="<?php echo e(url('list-business', $result->slug)); ?>" class="avatar avatar-xxl avatar-5by3 avatar-business">
                                    <img src="<?php echo e(asset('backend/assets/img/avatars/profiles/avatar-2.jpg')); ?>" alt="..." class="avatar-img rounded ">
                                </a>
                            </div>
                            <div class="col ml-n2">
                                <!-- Title -->
                                <h3 class="mb-2">
                                    <a href="<?php echo e(url('list-business', $result->slug)); ?>"><?php echo e($result->name); ?></a>
                                </h3>
                                <div class="row">
                                    <div class="col-auto">
                                        <a href="<?php echo e(url('write_a_review/'. $result->id)); ?>">
                                            <div class="rating text-primary " data-rate-value="<?php if(sizeof($result->reviews) > 1): ?><?php echo e(floor((($result->reviews->sum('stars')/sizeof($result->reviews))*2)/2 )); ?> <?php else: ?> 0 <?php endif; ?>"></div>
                                        </a>
                                    </div>
                                    <div class="col text-secondary total-reviews">
                                        <?php echo e(sizeof($result->reviews)); ?>

                                    </div>
                                </div>
                                <p class="text-secondary">
                                    <?php $__currentLoopData = $result->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge-danger"><?php echo e($c->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </p>
                                <!-- Text -->
                                <p class="small text-muted mb-1">
                                    <a href="tel:" class="text-primary">Phone: <?php echo e($result->phone); ?></a> 
                                </p>
                                <!-- Text -->
                                <p class="small text-muted mb-1">
                                    <span class="text-primary">Address: </span> <?php echo e($result->address); ?> Near <?php echo e($result->landmark); ?>, <?php echo e($result->town->name); ?>, <?php echo e($result->city->name); ?>

                                </p>
                            </div>

                        </div> <!-- / .row -->


                    </div> <!-- / .card-body -->
                    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($data['search_results']->appends(Request::all())->render()); ?>

            </div>
            
            <div class="col-md-5 p-0 ">
                <div id="" class="w-100 sticky-top" style="height: 90vh;">
                    <div id="business_map_canvas" class="h-100 w-100">

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="<?php echo e(URL::asset('backend/assets/js/maps.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wiz_truck\resources\views/frontend/search.blade.php ENDPATH**/ ?>