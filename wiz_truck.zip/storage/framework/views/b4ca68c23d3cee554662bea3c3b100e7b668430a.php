

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-12 col-lg-10 col-xl-8">

            <!-- Header -->
            <div class="header mt-md-5">
                <div class="header-body">
                    <div class="row align-items-center">
                        <div class="col">

                            <!-- Pretitle -->
                            <h6 class="header-pretitle">
                                Coupon
                            </h6>

                            <!-- Title -->
                            <h1 class="header-title">
                                Create a new Coupon
                            </h1>

                        </div>
                    </div> <!-- / .row -->
                </div>
            </div>
             <?php if(Session::has('success')): ?>
             <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
             <?php endif; ?>
             <?php if(Session::has('error')): ?>
             <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
             <?php endif; ?>

            <!-- Form -->
            <form class="mb-4" method="POST" action="<?php echo e(route('coupon.update',$coupon->id)); ?>" >

            <?php echo csrf_field(); ?>

   
                <!-- Project name -->
                <div class="form-group">

                    <!-- Label  -->
                    <label>
                        Code
                    </label>

                    <!-- Input -->
                    <input type="text" name="code" class="form-control" value="<?php echo e($coupon->code); ?>"

                </div>
                <!-- Project name -->
                <div class="form-group">

                    <!-- Label  -->
                    <label>
                        Type
                    </label>

                    <!-- Input -->
                    <div class="input-group">
                        <div class="input-group-prepend">
                          <label class="input-group-text" for="inputGroupSelect01">Options</label>
                        </div>
                        <select class="custom-select" id="inputGroupSelect01" name="type">
                          <option selected>Choose...</option>
                          <option value="percent">Percent</option>
                          <option value="fixed">Fixed</option>
                        </select>
                      </div>
                    

                </div>

                <div class="form-group">

                    <!-- Label  -->
                    <label>
                        Value
                    </label>

                    <!-- Input -->
                    <input type="number" name="value" class="form-control" value="<?php echo e($coupon->value); ?>">

                </div>

                <div class="form-group">

                    <!-- Label  -->
                    <label>
                        percent_off
                    </label>

                    <!-- Input -->
                    <input type="number" name="percent_off" class="form-control" value="<?php echo e($coupon->percent_off); ?>">

                </div>

                <div class="form-group">

                    <!-- Label  -->
                    <label>
                        Expire Date
                    </label>

                    <!-- Input -->
                    <input type="date" name="expiry_date" class="form-control" >value="<?php echo e($coupon->expiry_date); ?>"

                </div>
         

                <!-- Divider -->
                <hr class="mt-5 mb-5">

                <!-- Buttons -->
                <input type="submit" name="submit" value="Create Coupon" class="btn btn-block btn-primary">

                
               

            </form>

        </div>
    </div> <!-- / .row -->
</div>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Work\Wiz_truck\wiz_truck\resources\views/admin/coupons/edit.blade.php ENDPATH**/ ?>